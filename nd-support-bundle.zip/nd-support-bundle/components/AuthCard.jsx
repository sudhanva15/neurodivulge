import React from "react";
export default function AuthCard(){ 
  return (
    <div className="rounded-2xl border p-4 my-3">
      <div className="text-sm text-gray-600">AuthCard ready</div>
    </div>
  );
}
